package com.cg.bookstore.beans;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
@Entity
public class Books {
@Id
private int index;
private int isbn;
private String title;
private String author;
private double price;
private String publishDate;
private String bookImage;
private String description;
@OneToMany(mappedBy="account",cascade=CascadeType.ALL)
private Map<String, Category> categorys = new HashMap<String, Category>();

//@ManyToOne
//private Category category;
@OneToOne
private Review review;
//public Books() {}
//public Books(int index, int isbn, String title, String author, double price, String publishDate, String bookImage,
//		String description, Category category) {
//	super();
//	this.index = index;
//	this.isbn = isbn;
//	this.title = title;
//	this.author = author;
//	this.price = price;
//	this.publishDate = publishDate;
//	this.bookImage = bookImage;
//	this.description = description;
//	this.category = category;
//}
//public int getIndex() {
//	return index;
//}
//public void setIndex(int index) {
//	this.index = index;
//}
//public int getIsbn() {
//	return isbn;
//}
//public void setIsbn(int isbn) {
//	this.isbn = isbn;
//}
//public String getTitle() {
//	return title;
//}
//public void setTitle(String title) {
//	this.title = title;
//}
//public String getAuthor() {
//	return author;
//}
//public void setAuthor(String author) {
//	this.author = author;
//}
//public double getPrice() {
//	return price;
//}
//public void setPrice(double price) {
//	this.price = price;
//}
//public String getPublishDate() {
//	return publishDate;
//}
//public void setPublishDate(String publishDate) {
//	this.publishDate = publishDate;
//}
//public String getBookImage() {
//	return bookImage;
//}
//public void setBookImage(String bookImage) {
//	this.bookImage = bookImage;
//}
//public String getDescription() {
//	return description;
//}
//public void setDescription(String description) {
//	this.description = description;
//}
//public Category getCategory() {
//	return category;
//}
//public void setCategory(Category category) {
//	this.category = category;
//}
//@Override
//public String toString() {
//	return "Books [index=" + index + ", isbn=" + isbn + ", title=" + title + ", author=" + author + ", price=" + price
//			+ ", publishDate=" + publishDate + ", bookImage=" + bookImage + ", description=" + description
//			+ ", category=" + category + "]";
//}
//
//
}
