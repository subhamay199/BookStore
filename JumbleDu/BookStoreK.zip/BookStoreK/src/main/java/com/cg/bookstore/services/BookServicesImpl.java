package com.cg.bookstore.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.bookstore.beans.Customer;
import com.cg.bookstore.daoservices.BookDAO;
import com.cg.bookstore.daoservices.CustomerDAO;
import com.cg.bookstore.exceptions.CustomerNotFoundException;
import com.cg.capbook.beans.Account;
import com.cg.capbook.exceptions.AccountNotFoundException;
@Component("bookServices")
public class BookServicesImpl implements BookServices {
	@Autowired
	CustomerDAO customerDAO;
	@Autowired
	BookDAO bookDAO;
	@Override
	public Customer registerCustomer(Customer customer) {
		 return customerDAO.save(customer);
	}
	@Override
	public Customer getCustomer(String emailAddress) throws CustomerNotFoundException {
		return customerDAO.findById(emailAddress).orElseThrow(()-> new CustomerNotFoundException("Invalid Email ID"));
	}
	@Override
	public List<Customer> getAllCustomer() {
		return customerDAO.findAll();
	}
	@Override
	public Customer deleteCustomer(String emailAddress) throws CustomerNotFoundException {
		Customer customer=customerDAO.findById(emailAddress).orElseThrow(()-> new CustomerNotFoundException("Invalid Email ID"));
		customerDAO.deleteById(emailAddress);
		customer=customerDAO.save(customer);
		return customer;
	}
	@Override
	public Customer editCustomerDetails(String emailAddress, String password) throws CustomerNotFoundException {
		Customer customer=customerDAO.findById(emailAddress).orElseThrow(()-> new CustomerNotFoundException("Invalid Email ID"));
		if(!customer.getAddress().isEmpty())
			customer.setAddress(customer.getAddress());
		if(!customer.getCity().isEmpty())
			customer.setCity(customer.getCity());
		if(!(customer.getFullName().isEmpty()))
			customer.setFullName(customer.getFullName());
		if(!profile.getDateOfBirth().isEmpty())
			profile1.setDateOfBirth(profile.getDateOfBirth());
		if(!profile.getCountry().isEmpty())
			profile1.setCountry(profile.getCountry());
		if(!profile.getDesignation().isEmpty())
			profile1.setDesignation(profile.getDesignation());
		
			
		return customerDAO.save(customer);
		return null;
	}
}
