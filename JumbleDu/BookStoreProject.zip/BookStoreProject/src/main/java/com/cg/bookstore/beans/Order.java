package com.cg.bookstore.beans;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Order {
@Id
@GeneratedValue(strategy = GenerationType.AUTO)
private int index;
private String orderedBy;
private int bookCopies;
private double totalAmount;
private String recipientName;
private String recipientPhone;
private String shipTo;
private String orderStatus;
private String orderDate;

//@OneToMany
//private List<Books> books;


public Order() {}


@Override
public String toString() {
	return "Order [index=" + index + ", orderedBy=" + orderedBy + ", bookCopies=" + bookCopies + ", totalAmount="
			+ totalAmount + ", recipientName=" + recipientName + ", recipientPhone=" + recipientPhone + ", shipTo="
			+ shipTo + ", orderStatus=" + orderStatus + ", orderDate=" + orderDate  + "]";
}




}
