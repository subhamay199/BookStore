package com.cg.bookstore.beans;

public class Admin {

}
