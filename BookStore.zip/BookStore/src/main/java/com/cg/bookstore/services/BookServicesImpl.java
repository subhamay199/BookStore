package com.cg.bookstore.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.bookstore.beans.Customer;
import com.cg.bookstore.daoservices.BookDAO;
import com.cg.bookstore.exceptions.CustomerNotFoundException;
@Component("bookServices")
public class BookServicesImpl implements BookServices {
	@Autowired
	BookDAO bookDAO;
	@Override
	public Customer registerCustomer(Customer customer) {
		 return bookDAO.save(customer);
	}
	@Override
	public Customer getCustomer(String emailAddress) throws CustomerNotFoundException {
		return bookDAO.findById(emailAddress).orElseThrow(()-> new CustomerNotFoundException("Invalid Email ID"));
	}
	@Override
	public List<Customer> getAllCustomer() {
		return bookDAO.findAll();
	}
	@Override
	public Customer deleteCustomer(String emailAddress) throws CustomerNotFoundException {
		Customer customer=bookDAO.findById(emailAddress).orElseThrow(()-> new CustomerNotFoundException("Invalid Email ID"));
		bookDAO.deleteById(emailAddress);
		customer=bookDAO.save(customer);
		return customer;
	}
}
