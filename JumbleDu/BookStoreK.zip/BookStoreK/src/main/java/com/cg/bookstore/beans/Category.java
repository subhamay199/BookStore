package com.cg.bookstore.beans;

public class Category {
	private int index;
	private String categoryName;
//	@OneToMany(mappedBy = "category",cascade = CascadeType.ALL)
//	private Map<Integer, Books> books=new HashMap<Integer, Books>();
//	@ManyToOne
//	private Books books;
	public Category() {	}
	
}
